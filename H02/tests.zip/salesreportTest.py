'''
Created on Jan 13, 2016
@author: sgilbert
'''
from io import StringIO
import unittest
from checkresults import CustomTestRunner
from unittest.mock import patch
import salesreport # what we're testing
import os

class Test(unittest.TestCase):

    class MockOut(StringIO):
        def __init__self(self):
            super()._init__()
         
        def close(self): pass
     
        def getValue(self):
            result = super().getvalue()
            super().close()
            return result

#     def setUp(self):
#         self.old_stdin = sys.stdin
#         self.old_stdout = sys.stdout
#         self.out = StringIO()
#         sys.stdout = self.out
# 
#     def tearDown(self):
#         sys.stdin = self.old_stdin
#         sys.stdout = self.old_stdout

# Test open_files function
        
    def test01BadInputFile(self):
        '''Check for non-existing input file'''
        with patch('sys.stdout', new=StringIO()):
            actual = self._openBoth('junk.txt\nfake.txt\n')
            self._checkReturnType(actual)
            expected = None
            self.assertEqual(expected, actual[0], "Non-existent file should be None")
            self._closeBoth(actual)
        if os.path.exists("fake.txt"): os.remove("fake.txt")
        
        
    def test02BadOutputFile(self):
        '''Check for failure to create output file'''
        with patch('sys.stdout', new=StringIO()):
            actual = self._openBoth('icecream.txt\nread-only.txt\n')
            self._checkReturnType(actual)
            expected = None
            self.assertEqual(expected, actual[1], 'Should not create output file')
            self._closeBoth(actual)

    def test03OKOpenOutput(self):
        '''Check for ability to open output'''
        with patch('sys.stdout', new=StringIO()):
            actual = self._openBoth("icecream.txt\ntemp-report.txt\n")
            self._checkReturnType(actual)
            expected = None
            self.assertNotEqual(expected, actual[1], "Output should be opened!")
            self._closeBoth(actual)
        if os.path.exists("temp-report.txt"): os.remove("temp-report.txt")
        
    def test04OKOpenInput(self):
        '''Check for ability to open input'''
        with patch('sys.stdout', new=StringIO()):
            actual = self._openBoth("icecream.txt\ntemp-report.txt\n")
            self._checkReturnType(actual)
            expected = None
            self.assertNotEqual(expected, actual[0], "Input should be opened!")
            self._closeBoth(actual)
        if os.path.exists("temp-report.txt"): os.remove("temp-report.txt")
        
    def _checkReturnType(self, actual):
            self.assertIsInstance(actual, tuple, 'salesreport.open_files should return a tuple')
            self.assertEqual(len(actual), 2, 'salesreport.open_files should return a len(2) tuple')
        
    def _openBoth(self, strInput):
        with patch('sys.stdin', new = StringIO(strInput)):
            result = salesreport.open_files()
        return result
    
    def _closeBoth(self, files):
        try: files[0].close()
        except: pass
        try: files[1].close() 
        except: pass

# Test process files function

    def test05OutputHeading(self):
        '''Check heading is correct'''
        self._runTest1('                    ICE CREAM SALES REPORT', 0); 
#
    def test06OutputColumnHeadings(self):
        '''Check column headings are correct'''
        self._runTest1('Flavor              Store 1    Store 2    Store 3        Total', 1); 

    def test07OutputFirstLine(self):
        '''Test data #1 ->Check first line of output is correct'''
        self._runTest1('strawberry         9,285.15   8,276.10   8,705.00    26,266.25', 3);
         
    def test08OutputSecondLine(self):
        '''Test data #1 ->Check second line of output is correct'''
        self._runTest1('chocolate         10,225.25   9,025.00   9,505.00    28,755.25', 4);
        
    def test09OutputTotalsLine(self):
        '''Test data #1 ->Check totals line of output is correct'''
        self._runTest1('                  19,510.40  17,301.10  18,210.00    55,021.50', 6);

    def test10OutputFirstLine(self):
        '''Test data #2 ->Check first line of output is correct'''
        self._runTest2('vanilla            8,580.00   7,201.25   8,900.00    24,681.25', 3);
         
    def test11OutputSecondLine(self):
        '''Test data #2 ->Check second line of output is correct'''
        self._runTest2('rocky road         6,700.10   5,012.45   6,011.00    17,723.55', 4);
        
    def test12OutputTotalsLine(self):
        '''Test data #2 ->Check totals line of output is correct'''
        self._runTest2('                  15,280.10  12,213.70  14,911.00    42,404.80', 6);

    def test13OutputFirstLine(self):
        '''Test data #3 ->Check first line of output is correct'''
        self._runTest3('cookie dough       7,901.25   4,267.00   7,056.50    19,224.75', 3);
         
    def test14OutputSecondLine(self):
        '''Test data #3 ->Check second line of output is correct'''
        self._runTest3('strawberry         9,285.15   8,276.10   8,705.00    26,266.25', 4);
        
    def test14OutputThirdLine(self):
        '''Test data #3 ->Check third line of output is correct'''
        self._runTest3('chocolate         10,225.25   9,025.00   9,505.00    28,755.25', 5);
        
    def test15OutputTotalsLine(self):
        '''Test data #3 ->Check totals line of output is correct'''
        self._runTest3('                  27,411.65  21,568.10  25,266.50    74,246.25', 7);

    def _runTest1(self, expected, index):
        self._runTest(expected, index,
                     StringIO('strawberry 9285.15 8276.1 8705.0\nchocolate 10225.25 9025.0 9505.0\n'))

    def _runTest2(self, expected, index):
        self._runTest(expected, index,
                     StringIO('vanilla 8580.0 7201.25 8900.0\nrocky road 6700.1 5012.45 6011.0\n'))

    def _runTest3(self, expected, index):
        self._runTest(expected, index,
                     StringIO('cookie dough 7901.25 4267.0 7056.5\nstrawberry 9285.15 8276.1 8705.0\nchocolate 10225.25 9025.0 9505.0\n'))

    def _runTest(self, expected, index, fin): 
        self.out = Test.MockOut()
        salesreport.process_files((fin, self.out))
        self.actual = self.out.getvalue().split('\n')
        self.assertGreater(len(self.actual), index, 'Result has too few lines.')
        self.assertEquals(expected, self.actual[index])

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main(testRunner=CustomTestRunner(assignment='CS 132 Homework #2', 
                                              student=salesreport.student_id()))