'''
Created on Jan 13, 2016

@author: sgilbert
'''
import unittest
import sys

class CustomTestRunner:

    def __init__(self, assignment='', student='', stream=sys.stderr):
        self.results = []
        self.assignment = assignment
        self.student = student
        self.stream = stream

    def update(self, message):
        self.results.append(message)

    def run(self, test):
        "Run the given test case or test suite."
        result = _CustomTestResult(self)
        self.update('Testing ' + self.assignment + ' for ' + self.student + '\n')
        self.update('-' * 80 + '\n')
        test(result)
        self.update('-' * 80 + '\n')
        self.results.insert(1, '  %d/%d Tests Passing (%.2f%%)\n' % (result.points, result.testsRun, result.getScore()))
        for line in self.results:
            self.stream.write(line)
            
        return result
    

class _CustomTestResult(unittest.TestResult):
    """A test result class that can print

    CustomTestRunner.
    """
    def __init__(self, runner):
        unittest.TestResult.__init__(self)
        self.runner = runner
        self.points = 0

    def startTest(self, test):
        unittest.TestResult.startTest(self, test)
        # we should escape quotes here
        self.msg = test.shortDescription()

    def addSuccess(self, test):
        unittest.TestResult.addSuccess(self, test)
        self.runner.update(' + ' + self.msg + '\n')
        self.points += 1

    def addError(self, test, err):
        unittest.TestResult.addError(self, test, err)
        self.runner.update(' X ERROR: ' + self.msg + '->' 
                                + self._formatErrors(err))
    def addFailure(self, test, err):
        unittest.TestResult.addFailure(self, test, err)
        self.runner.update(' X Failure: ' + self.msg + '->' 
                                + self._formatErrors(err))

    def getScore(self):
        return self.points / self.testsRun * 100 
    
    def _formatErrors(self, err):
        errObj = err[1].args[0]
        pos = errObj.find('!=')
        end = errObj.find('\n')
        if end == -1: end = len(errObj) 
        if pos >= 0:
            errObj = ('\n    expected->' + errObj[0: pos] + '\n    found   ->' + errObj[pos + 3: end])
        return errObj + '\n' 